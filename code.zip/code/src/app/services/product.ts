export class product{
    productId:any;
    productName:any;
    productCompany:any;
    productFeatures:any;
    productPrice:any;
    productImage:any;
}